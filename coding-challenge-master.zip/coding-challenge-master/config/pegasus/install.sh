bash es.sh
bash kafka.sh
bash redis.sh
bash spark.sh
