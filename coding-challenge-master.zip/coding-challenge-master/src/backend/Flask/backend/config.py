api_base_url = '/api/v1'
es_base_url = {
    'venmo': 'http://52.41.91.188:9200/venmo/transaction',
    'styles': 'http://localhost:9200/cheermeapp/styles',
}
